package com.example.myexpensetracker;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.*;

public class AddExpenseActivity extends AppCompatActivity {

    AutoCompleteTextView titleInput;
    EditText amountInput, dateInput;
    Button btnSave, btnBackToHome;

    RecyclerView expenseRecycler;
    MonthlySummaryAdapter expenseAdapter;

    LinkedHashMap<String, List<Object>> monthlyExpenseMap = new LinkedHashMap<>();
    List<Object> displayList = new ArrayList<>();

    final Calendar myCalendar = Calendar.getInstance();

    Expense editingExpense = null;   // Used for editing mode

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        titleInput = findViewById(R.id.etTitle);
        amountInput = findViewById(R.id.etAmount);
        dateInput = findViewById(R.id.etDate);
        btnSave = findViewById(R.id.btnSave);
        btnBackToHome = findViewById(R.id.btnBackToHome);

        // Recycler view
        expenseRecycler = findViewById(R.id.recyclerExpensesInsideAdd);
        expenseRecycler.setLayoutManager(new LinearLayoutManager(this));

        // Auto suggestions
        String[] suggestions = {"Groceries", "Coffee", "Transport", "Shopping", "Bills", "Family", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, suggestions);
        titleInput.setAdapter(adapter);
        titleInput.setThreshold(1);

        // Date picker
        dateInput.setOnClickListener(v -> showDatePicker());
        updateLabel();

        // Save button
        btnSave.setOnClickListener(v -> saveExpense());

        // Back button
        btnBackToHome.setOnClickListener(v -> finish());

        loadMonthlyExpenseList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMonthlyExpenseList();
    }

    // ======================================================
    // SAVE OR UPDATE EXPENSE
    // ======================================================
    private void saveExpense() {

        String title = titleInput.getText().toString().trim();
        String amountStr = amountInput.getText().toString().trim();
        String date = dateInput.getText().toString().trim();

        if (title.isEmpty() || amountStr.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {

            if (editingExpense == null) {
                // ADD NEW EXPENSE
                Expense expense = new Expense();
                expense.title = title;
                expense.amount = Double.parseDouble(amountStr);
                expense.date = date;

                AppDatabase.getInstance(this).expenseDao().insert(expense);
                Toast.makeText(this, "Expense added!", Toast.LENGTH_SHORT).show();

            } else {
                // UPDATE EXISTING EXPENSE
                editingExpense.title = title;
                editingExpense.amount = Double.parseDouble(amountStr);
                editingExpense.date = date;

                AppDatabase.getInstance(this).expenseDao().update(editingExpense);
                Toast.makeText(this, "Expense updated!", Toast.LENGTH_SHORT).show();

                editingExpense = null;
                btnSave.setText("Save Expense");
            }

            resetForm();
            loadMonthlyExpenseList();

        } catch (Exception e) {
            Toast.makeText(this, "Invalid amount!", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetForm() {
        titleInput.setText("");
        amountInput.setText("");
        updateLabel();
    }

    private void loadMonthlyExpenseList() {

        AppDatabase db = AppDatabase.getInstance(this);
        List<Expense> expenseList = db.expenseDao().getAllExpenses();

        Collections.sort(expenseList, (a, b) -> b.date.compareTo(a.date));

        SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM yyyy");

        monthlyExpenseMap.clear();

        for (Expense exp : expenseList) {
            try {
                Date d = input.parse(exp.date);
                String monthName = monthFormat.format(d);

                if (!monthlyExpenseMap.containsKey(monthName))
                    monthlyExpenseMap.put(monthName, new ArrayList<>());

                monthlyExpenseMap.get(monthName).add(exp);

            } catch (Exception ignored) {}
        }

        expenseAdapter = new MonthlySummaryAdapter(this, monthlyExpenseMap, displayList);

        // ENABLE LONG PRESS FOR EXPENSE ITEMS
        expenseAdapter.setOnExpenseLongPressListener(expense -> showExpenseActions(expense));

        expenseRecycler.setAdapter(expenseAdapter);
    }


    // SHOW POPUP: Edit / Delete

    private void showExpenseActions(Expense expense) {

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Choose Action")
                .setMessage("Edit or delete this expense?")
                .setPositiveButton("Edit", (d, w) -> startEditing(expense))
                .setNegativeButton("Delete", (d, w) -> confirmDelete(expense))
                .setNeutralButton("Cancel", null)
                .show();
    }

    private void startEditing(Expense expense) {

        editingExpense = expense;

        titleInput.setText(expense.title);
        amountInput.setText(String.valueOf(expense.amount));
        dateInput.setText(expense.date);

        btnSave.setText("Update Expense");
    }

    private void confirmDelete(Expense expense) {

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Delete Expense")
                .setMessage("Are you sure you want to delete this?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    AppDatabase.getInstance(this).expenseDao().delete(expense);
                    Toast.makeText(this, "Expense deleted!", Toast.LENGTH_SHORT).show();
                    loadMonthlyExpenseList();
                })
                .setNegativeButton("No", null)
                .show();
    }


    // DATE PICKER

    private void showDatePicker() {
        DatePickerDialog.OnDateSetListener date = (view, year, month, day) -> {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, month);
            myCalendar.set(Calendar.DAY_OF_MONTH, day);
            updateLabel();
        };

        new DatePickerDialog(
                AddExpenseActivity.this,
                date,
                myCalendar.get(Calendar.YEAR),
                myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateLabel() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        dateInput.setText(sdf.format(myCalendar.getTime()));
    }
}
