package com.example.myexpensetracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MonthlySummaryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_MONTH = 0;
    private static final int VIEW_TYPE_ITEM = 1;

    Context context;

    private final LinkedHashMap<String, List<Object>> monthlyData;
    private final Map<String, Boolean> expandedState = new LinkedHashMap<>();
    private final List<Object> displayList;

    /* ======================================================
                     INCOME LONG-PRESS SUPPORT
       ====================================================== */

    public interface OnIncomeLongPressListener {
        void onIncomeLongPressed(Income income);
    }

    private OnIncomeLongPressListener incomeLongPressListener;

    public void setOnIncomeLongPressListener(OnIncomeLongPressListener listener) {
        this.incomeLongPressListener = listener;
    }

    /* ======================================================
                     EXPENSE LONG-PRESS SUPPORT
       ====================================================== */

    public interface OnExpenseLongPressListener {
        void onExpenseLongPressed(Expense expense);
    }

    private OnExpenseLongPressListener expenseLongPressListener;

    public void setOnExpenseLongPressListener(OnExpenseLongPressListener listener) {
        this.expenseLongPressListener = listener;
    }

    /* ======================================================
                           CONSTRUCTOR
       ====================================================== */

    public MonthlySummaryAdapter(Context context,
                                 LinkedHashMap<String, List<Object>> monthlyData,
                                 List<Object> displayList) {

        this.context = context;
        this.monthlyData = monthlyData;
        this.displayList = displayList;

        for (String month : monthlyData.keySet()) {
            expandedState.put(month, false);
        }

        rebuildDisplayList();
    }

    @Override
    public int getItemViewType(int position) {
        return (displayList.get(position) instanceof String)
                ? VIEW_TYPE_MONTH
                : VIEW_TYPE_ITEM;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        if (viewType == VIEW_TYPE_MONTH) {
            View view = LayoutInflater.from(context)
                    .inflate(R.layout.item_month_header, parent, false);
            return new MonthViewHolder(view);
        }

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_month_transaction, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull RecyclerView.ViewHolder holder, int position) {

        Object item = displayList.get(position);

        /* --------------------------
              MONTH HEADER ROW
           -------------------------- */
        if (holder instanceof MonthViewHolder) {
            String month = (String) item;
            MonthViewHolder h = (MonthViewHolder) holder;

            h.txtMonth.setText(month);
            boolean expanded = expandedState.get(month);

            h.txtMonth.setCompoundDrawablesWithIntrinsicBounds(
                    0, 0,
                    expanded ? R.drawable.ic_arrow_up : R.drawable.ic_arrow_down,
                    0
            );

            h.itemView.setOnClickListener(v -> {
                expandedState.put(month, !expanded);
                rebuildDisplayList();
            });

            return;
        }

        /* --------------------------
                INCOME / EXPENSE ROW
           -------------------------- */
        ItemViewHolder h = (ItemViewHolder) holder;

        if (item instanceof Expense) {
            Expense e = (Expense) item;

            h.title.setText("Expense: " + e.title);
            h.amount.setText("- $" + e.amount);
            h.date.setText(e.date);
            h.container.setBackgroundColor(0xFFFFEBEE);  // light red

            if (expenseLongPressListener != null) {
                h.itemView.setOnLongClickListener(v -> {
                    expenseLongPressListener.onExpenseLongPressed(e);
                    return true;
                });
            }
        }

        else if (item instanceof Income) {
            Income inc = (Income) item;

            h.title.setText("Income: " + inc.title);
            h.amount.setText("+ $" + inc.amount);
            h.date.setText(inc.date);
            h.container.setBackgroundColor(0xFFE8F5E9);  // light green

            if (incomeLongPressListener != null) {
                h.itemView.setOnLongClickListener(v -> {
                    incomeLongPressListener.onIncomeLongPressed(inc);
                    return true;
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        return displayList.size();
    }

    private void rebuildDisplayList() {
        displayList.clear();

        for (String month : monthlyData.keySet()) {
            displayList.add(month);

            if (expandedState.get(month)) {
                displayList.addAll(monthlyData.get(month));
            }
        }

        notifyDataSetChanged();
    }

    /* ======================================================
                           VIEW HOLDERS
       ====================================================== */

    static class MonthViewHolder extends RecyclerView.ViewHolder {
        TextView txtMonth;
        MonthViewHolder(@NonNull View itemView) {
            super(itemView);
            txtMonth = itemView.findViewById(R.id.txtMonth);
        }
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        LinearLayout container;
        TextView title, amount, date;

        ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            container = itemView.findViewById(R.id.itemContainer);
            title = itemView.findViewById(R.id.txtItemTitle);
            amount = itemView.findViewById(R.id.txtItemAmount);
            date = itemView.findViewById(R.id.txtItemDate);
        }
    }
}
