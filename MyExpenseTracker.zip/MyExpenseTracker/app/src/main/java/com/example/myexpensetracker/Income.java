package com.example.myexpensetracker;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity

public class Income {
        @PrimaryKey(autoGenerate = true)
        public int id;

        public String title;      // e.g., Salary, Freelance
        public double amount;
        public String date;
        public String type;       // Salary, Business, etc.
    }

