package com.example.myexpensetracker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SummaryActivity extends AppCompatActivity {

    TextView txtIncome, txtTotal, txtBalance, txtWarning;
    Button btnBack;
    LineChart lineChart;

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        // -------------------------------
        // FIND VIEWS
        // -------------------------------
        txtIncome = findViewById(R.id.txtIncome);
        txtTotal = findViewById(R.id.txtTotal);
        txtBalance = findViewById(R.id.txtBalance);
        txtWarning = findViewById(R.id.txtWarning);
        btnBack = findViewById(R.id.btnBack);
        lineChart = findViewById(R.id.lineChart);

        // Load totals
        loadSummaryData();

        // Load chart
        loadLineChart();

        btnBack.setOnClickListener(v -> finish());
    }

    // -------------------------------
    // SUMMARY NUMBERS
    // -------------------------------
    private void loadSummaryData() {
        AppDatabase db = AppDatabase.getInstance(this);

        // Total expenses
        double totalExpenses = 0;
        for (Expense e : db.expenseDao().getAllExpenses()) {
            totalExpenses += e.amount;
        }
        txtTotal.setText("$" + totalExpenses);

        // Total income
        Double totalIncome = db.incomeDao().getTotalIncome();
        if (totalIncome == null) totalIncome = 0.0;
        txtIncome.setText("$" + totalIncome);

        // Balance
        double balance = totalIncome - totalExpenses;
        txtBalance.setText("$" + balance);

        // Warning
        if (balance < 0) {
            txtWarning.setVisibility(View.VISIBLE);
        } else {
            txtWarning.setVisibility(View.GONE);
        }
    }

    // -------------------------------
    // FIXED LINE CHART (GREEN income / RED expense)
    // -------------------------------
    private void loadLineChart() {
        AppDatabase db = AppDatabase.getInstance(this);

        List<Expense> expenses = db.expenseDao().getAllExpenses();
        List<Income> incomes = db.incomeDao().getAllIncome();

        double[] monthlyIncome = new double[12];
        double[] monthlyExpense = new double[12];

        Calendar calendar = Calendar.getInstance();

        // Income loop
        for (Income inc : incomes) {
            try {
                Date parsedDate = sdf.parse(inc.date);
                calendar.setTime(parsedDate);
                int month = calendar.get(Calendar.MONTH);
                monthlyIncome[month] += inc.amount;
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        // Expense loop
        for (Expense exp : expenses) {
            try {
                Date parsedDate = sdf.parse(exp.date);
                calendar.setTime(parsedDate);
                int month = calendar.get(Calendar.MONTH);
                monthlyExpense[month] += exp.amount;
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        // Chart entries
        ArrayList<Entry> incomeEntries = new ArrayList<>();
        ArrayList<Entry> expenseEntries = new ArrayList<>();

        for (int m = 0; m < 12; m++) {
            incomeEntries.add(new Entry(m, (float) monthlyIncome[m]));
            expenseEntries.add(new Entry(m, (float) monthlyExpense[m]));
        }

        // Income dataset — GREEN
        LineDataSet incomeSet = new LineDataSet(incomeEntries, "Income");
        incomeSet.setColor(0xFF2E7D32);
        incomeSet.setCircleColor(0xFF2E7D32);
        incomeSet.setLineWidth(3f);
        incomeSet.setCircleRadius(4f);

        // Expenses dataset — RED
        LineDataSet expenseSet = new LineDataSet(expenseEntries, "Expenses");
        expenseSet.setColor(0xFFC62828);
        expenseSet.setCircleColor(0xFFC62828);
        expenseSet.setLineWidth(3f);
        expenseSet.setCircleRadius(4f);

        // Combine datasets
        LineData lineData = new LineData(incomeSet, expenseSet);
        lineChart.setData(lineData);

        // Chart styling
        Description desc = new Description();
        desc.setText("Monthly Income vs Expenses");
        lineChart.setDescription(desc);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        lineChart.invalidate(); // Refresh chart
    }
}
