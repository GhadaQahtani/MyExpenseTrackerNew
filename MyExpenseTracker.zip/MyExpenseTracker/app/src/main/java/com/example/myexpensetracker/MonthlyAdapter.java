package com.example.myexpensetracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MonthlyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_MONTH_HEADER = 0;
    private static final int TYPE_TRANSACTION = 1;

    List<Object> list;

    public MonthlyAdapter(List<Object> list) {
        this.list = list;
    }

    @Override
    public int getItemViewType(int position) {
        return (list.get(position) instanceof String) ? TYPE_MONTH_HEADER : TYPE_TRANSACTION;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if (viewType == TYPE_MONTH_HEADER) {
            View header = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_month_header, parent, false);
            return new MonthHeaderViewHolder(header);
        }

        View item = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_month_transaction, parent, false);
        return new TransactionViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof MonthHeaderViewHolder) {
            ((MonthHeaderViewHolder) holder).txtMonth.setText((String) list.get(position));
        }
        else if (holder instanceof TransactionViewHolder) {

            Object obj = list.get(position);
            TransactionViewHolder vh = (TransactionViewHolder) holder;

            if (obj instanceof Expense) {
                Expense e = (Expense) obj;
                vh.title.setText("Expense: " + e.title);
                vh.amount.setText("- $" + e.amount);
                vh.amount.setTextColor(0xFFFF4444);
                vh.date.setText(e.date);
            }
            else {
                Income i = (Income) obj;
                vh.title.setText("Income: " + i.title);
                vh.amount.setText("+ $" + i.amount);
                vh.amount.setTextColor(0xFF00AA00);
                vh.date.setText(i.date);
            }
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    // Header ViewHolder
    static class MonthHeaderViewHolder extends RecyclerView.ViewHolder {
        TextView txtMonth;

        public MonthHeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            txtMonth = itemView.findViewById(R.id.txtMonth);
        }
    }

    // Transaction ViewHolder
    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView title, amount, date;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.txtTitle);
            amount = itemView.findViewById(R.id.txtAmount);
            date = itemView.findViewById(R.id.txtDate);
        }
    }
}
