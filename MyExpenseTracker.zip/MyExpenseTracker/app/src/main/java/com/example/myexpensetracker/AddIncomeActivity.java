package com.example.myexpensetracker;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddIncomeActivity extends AppCompatActivity {

    EditText titleInput, amountInput, dateInput;
    Spinner typeSpinner;
    Button saveIncomeBtn, backHomeBtn;

    RecyclerView incomeRecycler;
    MonthlySummaryAdapter incomeAdapter;

    LinkedHashMap<String, List<Object>> monthlyIncomeMap = new LinkedHashMap<>();
    List<Object> displayList = new ArrayList<>();

    final Calendar myCalendar = Calendar.getInstance();

    Income editingIncome = null;  // stores the item being edited

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_income);

        // -------- INITIALIZE INPUTS
        titleInput = findViewById(R.id.etIncomeTitle);
        amountInput = findViewById(R.id.etIncomeAmount);
        dateInput = findViewById(R.id.etIncomeDate);
        typeSpinner = findViewById(R.id.incomeTypeSpinner);
        saveIncomeBtn = findViewById(R.id.btnSaveIncome);
        backHomeBtn = findViewById(R.id.btnBackToHomeIncome);

        // -------- RECYCLER VIEW
        incomeRecycler = findViewById(R.id.recyclerIncomeInsideAdd);
        incomeRecycler.setLayoutManager(new LinearLayoutManager(this));

        // -------- SPINNER VALUES
        String[] incomeTypes = {"Salary", "Business", "Freelance", "Investments", "Other"};
        typeSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                incomeTypes));

        // -------- DATE PICKER
        dateInput.setOnClickListener(v -> showDatePicker());
        updateLabel();

        // -------- SAVE BUTTON
        saveIncomeBtn.setOnClickListener(v -> saveIncome());

        // -------- BACK BUTTON
        backHomeBtn.setOnClickListener(v -> finish());

        // -------- LOAD LIST
        loadMonthlyIncomeList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMonthlyIncomeList();
    }

    // SAVE OR UPDATE INCOME

    private void saveIncome() {

        String title = titleInput.getText().toString().trim();
        String amountStr = amountInput.getText().toString().trim();
        String date = dateInput.getText().toString().trim();
        String type = typeSpinner.getSelectedItem().toString();

        if (title.isEmpty() || amountStr.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr);

            if (editingIncome == null) {
                // ------------------ NEW INCOME ------------------
                Income income = new Income();
                income.title = title;
                income.amount = amount;
                income.date = date;
                income.type = type;

                AppDatabase.getInstance(this).incomeDao().insert(income);
                Toast.makeText(this, "Income added!", Toast.LENGTH_SHORT).show();

            } else {
                // ------------------ UPDATE EXISTING ------------------
                editingIncome.title = title;
                editingIncome.amount = amount;
                editingIncome.date = date;
                editingIncome.type = type;

                AppDatabase.getInstance(this).incomeDao().update(editingIncome);
                Toast.makeText(this, "Income updated!", Toast.LENGTH_SHORT).show();

                editingIncome = null;
                saveIncomeBtn.setText("Save Income");
            }

            resetForm();
            loadMonthlyIncomeList();

        } catch (Exception e) {
            Toast.makeText(this, "Invalid amount!", Toast.LENGTH_SHORT).show();
        }
    }

    // Clear input fields after save/update
    private void resetForm() {
        titleInput.setText("");
        amountInput.setText("");
        updateLabel(); // resets date
        typeSpinner.setSelection(0);
    }

    // LOAD MONTHLY COLLAPSIBLE LIST

    private void loadMonthlyIncomeList() {

        AppDatabase db = AppDatabase.getInstance(this);
        List<Income> incomeList = db.incomeDao().getAllIncome();

        // Sort by date (newest first)
        Collections.sort(incomeList, (a, b) -> b.date.compareTo(a.date));

        SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM yyyy");

        monthlyIncomeMap.clear();

        for (Income inc : incomeList) {
            try {
                Date d = input.parse(inc.date);
                String monthName = monthFormat.format(d);

                monthlyIncomeMap.putIfAbsent(monthName, new ArrayList<>());
                monthlyIncomeMap.get(monthName).add(inc);

            } catch (Exception ignore) {}
        }

        displayList.clear(); // IMPORTANT fix to avoid duplicates

        incomeAdapter = new MonthlySummaryAdapter(this, monthlyIncomeMap, displayList);

        // -------- LONG PRESS HANDLER --------
        incomeAdapter.setOnIncomeLongPressListener(income -> showIncomeActions(income));

        incomeRecycler.setAdapter(incomeAdapter);
    }

    // LONG PRESS POPUP: EDIT / DELETE

    private void showIncomeActions(Income income) {

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Choose Action")
                .setMessage("What do you want to do?")
                .setPositiveButton("Edit", (d, w) -> startEditing(income))
                .setNegativeButton("Delete", (d, w) -> confirmDelete(income))
                .setNeutralButton("Cancel", null)
                .show();
    }

    private void startEditing(Income income) {

        editingIncome = income;

        titleInput.setText(income.title);
        amountInput.setText(String.valueOf(income.amount));
        dateInput.setText(income.date);

        // Restore spinner position
        String[] arr = {"Salary", "Business", "Freelance", "Investments", "Other"};
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(income.type)) {
                typeSpinner.setSelection(i);
                break;
            }
        }

        saveIncomeBtn.setText("Update Income");
    }

    private void confirmDelete(Income income) {

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Delete Income")
                .setMessage("Are you sure you want to delete this income?")
                .setPositiveButton("Yes", (d, w) -> {
                    AppDatabase.getInstance(this).incomeDao().delete(income);
                    Toast.makeText(this, "Income deleted!", Toast.LENGTH_SHORT).show();
                    loadMonthlyIncomeList();
                })
                .setNegativeButton("No", null)
                .show();
    }


    // DATE PICKER

    private void showDatePicker() {
        DatePickerDialog.OnDateSetListener date = (view, year, month, day) -> {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, month);
            myCalendar.set(Calendar.DAY_OF_MONTH, day);
            updateLabel();
        };

        new DatePickerDialog(
                AddIncomeActivity.this,
                date,
                myCalendar.get(Calendar.YEAR),
                myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateLabel() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        dateInput.setText(sdf.format(myCalendar.getTime()));
    }
}
