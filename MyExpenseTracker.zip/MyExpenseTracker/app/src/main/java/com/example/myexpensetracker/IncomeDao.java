package com.example.myexpensetracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface IncomeDao {

    @Insert
    void insert(Income income);

    @Query("SELECT * FROM income")
    List<Income> getAllIncome();

    @Query("SELECT SUM(amount) FROM income")
    Double getTotalIncome();

    @Delete
    void delete(Income income);

    @Update
    void update(Income income); // <-- REQUIRED for editing
}
