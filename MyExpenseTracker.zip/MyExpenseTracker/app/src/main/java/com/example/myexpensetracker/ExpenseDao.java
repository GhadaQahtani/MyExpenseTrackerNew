package com.example.myexpensetracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ExpenseDao {

    @Insert
    void insert(Expense expense);

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    List<Expense> getAllExpenses();

    @Update
    void update(Expense expense);

    @Delete
    void delete(Expense expense);

    @Query("SELECT SUM(amount) FROM expenses")
    Double getTotalExpenses();
}
