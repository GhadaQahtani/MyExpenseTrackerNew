package com.example.myexpensetracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NameSetupActivity extends AppCompatActivity {

    EditText edtName;
    Button btnSaveName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name_setup);

        edtName = findViewById(R.id.edtName);
        btnSaveName = findViewById(R.id.btnSaveName);

        btnSaveName.setOnClickListener(v -> {
            String name = edtName.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save to SharedPreferences
            SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
            prefs.edit().putString("userName", name).apply();

            // Go to MainActivity
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}
