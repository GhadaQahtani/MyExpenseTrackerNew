package com.example.myexpensetracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    MonthlySummaryAdapter monthlySummaryAdapter;

    // Final dataset passed to adapter
    LinkedHashMap<String, List<Object>> monthlyMap = new LinkedHashMap<>();

    // Flat list used by adapter after expansion/collapse
    List<Object> displayList = new ArrayList<>();

    Button btnAddExpense, btnAddIncome, btnSummary;
    TextView txtWelcomeUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load saved username
        SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);

        if (!prefs.contains("userName")) {
            startActivity(new Intent(MainActivity.this, NameSetupActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        String userName = prefs.getString("userName", "User");

        // UI
        recyclerView = findViewById(R.id.recyclerView);
        btnAddExpense = findViewById(R.id.btnAddExpense);
        btnAddIncome = findViewById(R.id.btnAddIncome);
        btnSummary = findViewById(R.id.btnSummary);
        txtWelcomeUser = findViewById(R.id.txtWelcomeUser);

        txtWelcomeUser.setText("Welcome, " + userName + "!");

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadMonthlyData();

        // Buttons
        btnAddExpense.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddExpenseActivity.class)));

        btnAddIncome.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddIncomeActivity.class)));

        btnSummary.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SummaryActivity.class)));

        Toast.makeText(this, "Welcome back, " + userName + "!", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMonthlyData();
    }

    // -------------------------------------------
    // ✔ GROUP INCOME + EXPENSE BY MONTH
    // ✔ STORE THEM IN A MAP → { Month : Items }
    // -------------------------------------------
    private void loadMonthlyData() {

        AppDatabase db = AppDatabase.getInstance(this);

        List<Expense> expenses = db.expenseDao().getAllExpenses();
        List<Income> incomes = db.incomeDao().getAllIncome();

        List<Object> allItems = new ArrayList<>();
        allItems.addAll(expenses);
        allItems.addAll(incomes);

        // Sort by date descending
        Collections.sort(allItems, (a, b) -> {
            String da = (a instanceof Expense) ? ((Expense) a).date : ((Income) a).date;
            String dbb = (b instanceof Expense) ? ((Expense) b).date : ((Income) b).date;
            return dbb.compareTo(da);
        });

        // Format months
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM yyyy");

        monthlyMap.clear();

        for (Object item : allItems) {
            try {
                String dateStr = (item instanceof Expense)
                        ? ((Expense) item).date
                        : ((Income) item).date;

                Date d = inputFormat.parse(dateStr);
                String monthName = monthFormat.format(d);

                if (!monthlyMap.containsKey(monthName))
                    monthlyMap.put(monthName, new ArrayList<>());

                monthlyMap.get(monthName).add(item);

            } catch (Exception ignored) {}
        }

        // Create adapter with new data
        monthlySummaryAdapter =
                new MonthlySummaryAdapter(this, monthlyMap, displayList);

        recyclerView.setAdapter(monthlySummaryAdapter);
    }
}
