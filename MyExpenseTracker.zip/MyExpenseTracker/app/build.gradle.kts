// The plugins block should be at the top level and contain all plugins.
plugins {
    alias(libs.plugins.android.application)

    // Enable Kotlin Kapt for Room (even if project is Java, safe to keep)
    id("org.jetbrains.kotlin.kapt") version "1.9.0" apply false
}

android {
    namespace = "com.example.myexpensetracker"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.myexpensetracker"
        minSdk = 27
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Dependencies from libs.versions.toml
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    // RecyclerView & CardView
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.cardview:cardview:1.0.0")

    // -------------------------
    // ROOM DATABASE
    // -------------------------
    val room_version = "2.6.1"

    implementation("androidx.room:room-runtime:$room_version")
    annotationProcessor("androidx.room:room-compiler:$room_version")

    // (If your project uses Kotlin, add this line)
    // kapt("androidx.room:room-compiler:$room_version")

    // -------------------------
    // MPANDROIDCHART (Line chart)
    // -------------------------
    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

    // Test dependencies
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
